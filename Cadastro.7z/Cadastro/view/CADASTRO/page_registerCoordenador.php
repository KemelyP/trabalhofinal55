<?php   
   include_once 'header.php';
   include_once 'board.php';
?>


<form action="../../controller/vaga/insert_vaga.php" method="POST">
    <div class="container" style="color: white;">
        <div class="form">
            <div class="form-group">
                Nome:
                <input type="text" class="form-control" name="nome" placeholder="Nome" required autofocus/>
            </div>
            <div class="form-group">
                Curso:
                <div class="radio-item">
                    <input type="radio" id="ECA" name="curso" value="ECA" checked>
                    <label for="ECA">ECA</label>
                </div>
                <div class="radio-item">
                    <input type="radio" id="ECO" name="curso" value="ECO">
                    <label for="ECO">ECO</label>
                </div>
            </div>
 
            <div class="form-group">
                <button class="btn btn-outline-danger btn-lg">Cadastrar</button>
            </div>
        </div>
    </div>
</form>