<?php   
   include_once 'header.php';
   include_once 'board.php';
?>


<form action="../../controller/aluno/insert_aluno.php" method="POST">
    <div class="container" style="color: white;">
        <div class="form">
            <div class="form-group">
                Nome:
                <input type="text" class="form-control" name="nome" placeholder="Nome" required autofocus/>
            </div>
            <div class="form-group">
                Matrícula:
                <input type="text" class="form-control" name="matricula" placeholder="Matrícula" required/>
            </div>
            <div class="form-group">
                Curso:
                <div class="radio-item">
                    <input type="radio" id="ECA" name="curso" value="ECA" checked>
                    <label for="ECA">ECA</label>
                </div>
                <div class="radio-item">
                    <input type="radio" id="ECO" name="curso" value="ECO">
                    <label for="ECO">ECO</label>
                </div>
            </div>
            <div class="form-group">
               Ano e mês de ingresso: 
                <input type="month" class="form-control"
                 name="month" placeholder="Data"
                 style="width:40%" required>
                 <br>
            </div>
            <div class="form-group">
                <button class="btn btn-outline-danger btn-lg">Cadastrar</button>
            </div>
        </div>
    </div>
</form>