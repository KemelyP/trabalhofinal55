<?php
    include_once 'header.php';
    include_once 'board.php';
?>


<a href="../../view/solicitacao/page_registerSolicitação.php" class="btn btn-secondary btn-lg active" role="button" aria-pressed="true">Solicitar Ajuste</a>
or
<a href="#" class="btn btn-secondary btn-lg active" role="button" aria-pressed="true">Visualizar Solicitações</a>


<?php
    include_once "../../view/includes/footer.php";
?>


