<?php
    include_once '../../view/includes/header.php'

?>

<form action="../../controller/solicitacao/insert_solicitacao.php" method="POST">
    <div class="container">
        <div class="form text-light">
            <div class="form-group">
                Nome da disciplina:
            <input type="text" class="form-control" name="nomedisc" placeholder="nome" required autofocus />
            <br>
            </div>
            
            <div class="form-group">
                Código da disciplina:
            <input type="text" class="form-control" name="codigo" placeholder="Código" required />
            <br>
            </div>

            
            <div class="form-group">
                Você já fez essa solicitação antes?
                <div class="radio-item">
                 <input style="background-color: #323edb" type="radio" id="ativoA" name="ativo" value="s" checked>
                 <label for="ativoA">Sim</label>
                </div>

                <div class="radio-item">
                 <input style="background-color: #6a2cb1" type="radio" id="ativoB" name="ativo" value="n">
                 <label for="ativoB">Não</label>
                </div>
        </div>


        <div class="form-group">
                Solicitação:
                <div class="radio-item">
                 <input type="radio" id="ativoA" name="acao" value="s" checked>
                 <label for="ativoA">Incluir</label>
                </div>

                <div class="radio-item">
                 <input type="radio" id="ativoB" name="acao" value="n">
                 <label for="ativoB">Excluir</label>
                </div>

                <div class="radio-item">
                 <input type="radio" id="ativoC" name="acao" value="n">
                 <label for="ativoB">Solicitar quebra de pré-requisito</label>
                </div>
        </div>

    
        <div class="form-group">
            <button class="btn btn-outline-alt btn-lg">
                Enviar
            </button>
        </div>
        </div>
    </div>
</form>

<?php
     include_once '../includes/footer.php'; 
?>
