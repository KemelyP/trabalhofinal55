<?php   
   include_once '../../model/Conexao.class.php';
   include_once '../../model/Entity.class.php';
   include_once 'headerAluno.php';

   $alunoEntity = new Entity();
?>

<div class="container mt-5">

  <div style="color:black">    
  <!-- vagas -->
  <div class="row">  
           <?php foreach($vagaEntity->list("vaga") as $vaga) { ?> 
              <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="card">
                <div class="card-header">
                    <h5 class="card-title"><?php echo $vaga['titulo']; ?></h5>
                  </div>
                  <div class="card-body">
                    <p class="card-text"><?php echo $vaga['descricao']; ?>          
                    </p>        
                  </div>
                  <div class="card-footer direita">

                    <form action="./page_update.php" method="POST">
                      <input type="hidden" name="id" value="<?=$vaga['id']?>">
                      <button class="btn btn-outile-danger espaco">
                        Alterar
                      </button>
                    </form>

                    <form action="../../controller/vaga/delete_vaga.php" method="POST">
                      <input type="hidden" name="id" value="<?=$vaga['id']?>">
                      <button class="btn btn-outile-danger espaco">
                        Deletar
                      </button>
                    </form>


                  </div>
                </div>
              </div>     
            <?php } ?>


 <br> 
  <!-- container -->
</div>

<?php
     include_once '../includes/footer.php'; 
?>

