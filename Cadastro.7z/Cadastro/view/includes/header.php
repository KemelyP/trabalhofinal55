<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link rel="shortcut icon" href="./assets/img/icone.png" type="image/png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css" />

    <!-- Fontawesome 5 -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">

    <!-- GoogleFonts - Raleway -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@500&display=swap" rel="stylesheet">
    
    <!-- CSS Personalizado-->
    <link rel="stylesheet" href="./assets/css/master.css" />

  <!-- Javascript -->
    <script src="./assets/js/jquery-3.5.1.js"></script>   
   <script src="./assets/js/bootstrap.min.js"></script> 
  

    <title>Sistema de Ajuste de Matrícula</title>
  </head>
  <body class="bg-Vaga">

    <div style = "padding: 0px; " class="container"> <!-- Esse container fecha na página footer.php>
 Navbar -->

    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-vaga-nav " >
      <a class="navbar-brand" href="#">Ajuste de Matrícula</a>
      

      <div class="collapse navbar-collapse" id="menu">
        <ul class="navbar-nav mr-auto">

        <li class="nav-item active dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Login
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="./view/aluno/boardAluno.php">Aluno</a>
          <a class="dropdown-item" href="./view/coordenador/boardCoord.php">Coordenador</a>
        </div>

        <li class="nav-item active dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Cadastrar
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="./view/CADASTRO/page_registerAluno.php">Aluno</a>
          <a class="dropdown-item" href="./view/CADASTRO/page_registerCoordenador.php">Coordenador</a>
        </div>

        </ul>      
      </div>
    </nav>
</div>
  



    


