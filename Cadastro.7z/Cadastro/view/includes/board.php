<?php   
   include_once './model/Conexao.class.php';
   include_once './model/Entity.class.php';

   $vagaEntity = new Entity();
?>

<div class="container">
  <!-- vagas -->
  


  <div class="jumbotron container-fluid">
        <h1 class="d-flex justify-content-center">Sistema de Ajuste de Matrículas</h1>
    </div>

    

 <br> 
  <!-- container -->
</div>
