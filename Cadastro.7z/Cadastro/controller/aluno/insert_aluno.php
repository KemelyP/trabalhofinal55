<?php
    include_once '../../model/Conexao.class.php';
    include_once '../../model/Entity.class.php';

    $alunoEntity = new Entity();
    $data = $_POST;

    if(isset($data) && !empty($data))
    {
        //chamar o método de insert do banco
        $alunoEntity->insert("aluno",$data);
        header("Location: ../../view/aluno/boardAluno.php");
    }

?>